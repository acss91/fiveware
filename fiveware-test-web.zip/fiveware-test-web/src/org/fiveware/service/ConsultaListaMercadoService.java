
package org.fiveware.service;

import java.util.List;

import org.fiveware.model.Produto;



public interface ConsultaListaMercadoService {
	public List<Produto> listCompra();

}
