package org.fiveware.service;

import java.util.List;

import org.fiveware.model.Produto;

public interface InsereListaMercadoService {
	public void addProduto(Produto produto);

}
