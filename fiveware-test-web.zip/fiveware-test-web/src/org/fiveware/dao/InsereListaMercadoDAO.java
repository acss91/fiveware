package org.fiveware.dao;
import org.fiveware.model.Produto;
public interface InsereListaMercadoDAO {
	public void addProduto(Produto produto);
}
