package org.fiveware.dao;

import java.util.List;

import org.fiveware.model.Produto;



public interface ConsultaListaMercadoDAO{
	public List <Produto> listCompra();

}
